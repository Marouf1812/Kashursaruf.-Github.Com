const canvas = document.getElementById('gameCanvas');

const ctx = canvas.getContext('2d');

const eatSound = document.getElementById('eatSound');

const hitSound = document.getElementById('hitSound');

// Game constants

let box = 20; // Size of snake and dot

let snake = [{ x: 200, y: 200 }];

let food = { x: 0, y: 0 };

let direction = null;

let speed = 200; // Initial speed in ms

let score = 0;

// LocalStorage helpers

function saveHighScore(level, score) {

  const highScore = localStorage.getItem(`highScore_${level}`) || 0;

  if (score > highScore) {

    localStorage.setItem(`highScore_${level}`, score);

  }

}

function getHighScore(level) {

  return localStorage.getItem(`highScore_${level}`) || 0;

}

// Touch controls

canvas.addEventListener('touchstart', handleTouchStart);

canvas.addEventListener('touchmove', handleTouchMove);

let xDown = null;

let yDown = null;

function handleTouchStart(evt) {

  const firstTouch = evt.touches[0];

  xDown = firstTouch.clientX;

  yDown = firstTouch.clientY;

}

function handleTouchMove(evt) {

  if (!xDown || !yDown) return;

  const xUp = evt.touches[0].clientX;

  const yUp = evt.touches[0].clientY;

  const xDiff = xDown - xUp;

  const yDiff = yDown - yUp;

  if (Math.abs(xDiff) > Math.abs(yDiff)) {

    direction = xDiff > 0 ? 'LEFT' : 'RIGHT';

  } else {

    direction = yDiff > 0 ? 'UP' : 'DOWN';

  }

  xDown = null;

  yDown = null;

}

// Reset game

function resetGame() {

  snake = [{ x: 200, y: 200 }];

  direction = null;

  score = 0;

  placeFood();

}

// Place food

function placeFood() {

  food.x = Math.floor((Math.random() * canvas.width) / box) * box;

  food.y = Math.floor((Math.random() * canvas.height) / box) * box;

}

// Draw snake and food

function draw() {

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Draw snake

  for (let i = 0; i < snake.length; i++) {

    ctx.fillStyle = i === 0 ? 'lime' : 'green';

    ctx.fillRect(snake[i].x, snake[i].y, box, box);

  }

  // Draw food

  ctx.fillStyle = 'red';

  ctx.fillRect(food.x, food.y, box, box);

  // Display score

  ctx.fillStyle = 'white';

  ctx.font = '20px Arial';

  ctx.fillText(`Score: ${score}`, 10, 20);

}

// Update snake position

function update() {

  const head = { ...snake[0] };

  switch (direction) {

    case 'UP':

      head.y -= box;

      break;

    case 'DOWN':

      head.y += box;

      break;

    case 'LEFT':

      head.x -= box;

      break;

    case 'RIGHT':

      head.x += box;

      break;

    default:

      return;

  }

  // Collision detection

  if (

    head.x < 0 ||

    head.y < 0 ||

    head.x >= canvas.width ||

    head.y >= canvas.height ||

    snake.some((segment) => segment.x === head.x && segment.y === head.y)

  ) {

    hitSound.play();

    alert(`Game Over! Your score: ${score}`);

    resetGame();

    return;

  }

  // Eating food

  if (head.x === food.x && head.y === food.y) {

    eatSound.play();

    score++;

    placeFood();

  } else {

    snake.pop();

  }

  snake.unshift(head);

}

// Game loop

function gameLoop() {

  setTimeout(() => {

    update();

    draw();

    gameLoop();

  }, speed);

}

// Initialize

function init(level) {

  resetGame();

  switch (level) {

    case 'easy':

      speed = 200;

      break;

    case 'moderate':

      speed = 150;

      break;

    case 'hard':

      speed = 100;

      break;

  }

  saveHighScore(level, score);

  gameLoop();

}

// Event listeners for levels

document.getElementById('easy').addEventListener('click', () => init('easy'));

document.getElementById('moderate').addEventListener('click', () => init('moderate'));

document.getElementById('hard').addEventListener('click', () => init('hard'));

placeFood();

draw();